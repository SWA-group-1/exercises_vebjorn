package vebjorsv.mygdx.game.desktop;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import vebjorsv.mygdx.game.Helicopter;
import vebjorsv.mygdx.game.Task1;
import vebjorsv.mygdx.game.Task2;
import vebjorsv.mygdx.game.Task3;
import vebjorsv.mygdx.game.Task4.App;
import vebjorsv.mygdx.game.Task4.PLAYstate;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.width = App.WIDTH;config.height = App.HEIGHT;config.title = App.APP_TITLE;
		new LwjglApplication(new Task1(), config); //change "Task1" with "TaskX" or "App" dependent on which program to run
	}
}
