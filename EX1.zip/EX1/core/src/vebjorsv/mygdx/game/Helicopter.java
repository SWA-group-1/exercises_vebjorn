package vebjorsv.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

public class Helicopter extends ApplicationAdapter {
	Texture helicopter; Sprite sprite;
	float speed_x; float speed_y;
	int x; int y;
	private static final int FRAME_COLS = 1, FRAME_ROWS = 1;
	Animation<TextureRegion> walkAnimation; // Must declare frame type (TextureRegion)
	TextureRegion currentFrame;
	private Rectangle bounds;

	public Helicopter(int x, int y, float speed){
		helicopter = new Texture(Gdx.files.internal("heli.png"));
		sprite = new com.badlogic.gdx.graphics.g2d.Sprite(helicopter);
		sprite.flip(true, false);
		this.x = x;
		this.y = y;
		speed_y = speed;
		speed_x = speed;

		TextureRegion[][] tmp = TextureRegion.split(helicopter,
				helicopter.getWidth() / FRAME_COLS,
				helicopter.getHeight() / FRAME_ROWS);

		TextureRegion[] walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
		int index = 0;
		for (int i = 0; i < FRAME_ROWS; i++) {
			for (int j = 0; j < FRAME_COLS; j++) {
				walkFrames[index++] = tmp[i][j]; } }

		walkAnimation = new Animation<TextureRegion>(0.1f, walkFrames);
		bounds = new Rectangle(x, y, sprite.getWidth()/2, sprite.getHeight()/3);
	}

	public void update(float stateTime){
		currentFrame = walkAnimation.getKeyFrame(stateTime, true);
		if (x > Gdx.graphics.getWidth() - sprite.getWidth() / 4) {
			speed_x = -speed_x; }
		if(x < 0 + sprite.getWidth() / 4){
			speed_x = -speed_x; }
		if (y > Gdx.graphics.getHeight() - sprite.getHeight() / 6) {
			speed_y = -speed_y; }
		if(y < 0 + sprite.getHeight() ){
			speed_y = -speed_y; }
		x += speed_x;
		y += speed_y;
		bounds.setPosition(x, y); }

	public boolean collide(Rectangle rect){
		return rect.overlaps(bounds);
	}
	public Rectangle getBounds(){
		return bounds;
	}
	public Sprite getSprite(){
		return this.sprite;
	}
	public int getX(){
		return this.x;
	}
	public int getY(){
		return  this.y;
	}
	public float getSpeedY(){
		return this.speed_y;
	}
	public float getSpeedX(){
		return this.speed_x;
	}
	public void setSpeedY(float speedY){
		this.speed_y = speedY;
	}
	public void setSpeedX(float speedX){
		this.speed_x = speedX;
	}
	public TextureRegion getCurrentFrame(){
		return this.currentFrame;
	}
}
