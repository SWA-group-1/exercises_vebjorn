package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class App extends ApplicationAdapter {
    public static String APP_TITLE = "Pong";
    public static final int HEIGHT = 450; public static final int WIDTH = 750;
    private SpriteBatch batch; private GSm gsm;

    @Override
    public void create () {
        batch = new SpriteBatch();
        gsm = new GSm();
        gsm.push(new MENUstate(gsm)); }

    @Override
    public void render () {
        Gdx.gl.glClearColor(179, 75, 38, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        gsm.update(Gdx.graphics.getDeltaTime());
        gsm.render(batch); }

    @Override
    public void dispose () {
        batch.dispose();
    }
}
