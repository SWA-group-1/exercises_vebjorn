package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class WINNERstate extends State {
    private Texture win;

    public WINNERstate(GSm gsm, boolean leftWin, boolean rightWin) {
        super(gsm);
        if(leftWin){
            win = new Texture("winner_L.png"); }
        if(rightWin){
            win = new Texture("winner_R.png"); } }

    @Override
    public void handleInput() {
        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            gsm.set(new PLAYstate(gsm, 0, 0)); } }

    @Override
    public void update(float dt) {
        handleInput(); }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(win, 0, 0);
        sb.draw(win, Gdx.graphics.getWidth()/2, Gdx.graphics.getHeight());
        sb.end(); }

    @Override
    public void dispose() {
        win.dispose();
    }
}
