package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class PLAYstate extends State {
    private Ball ball;
    private ShapeRenderer shape;
    private Wall wall_1, wall_2;
    private int scoreL, scoreR;
    BitmapFont font;

    public PLAYstate(GSm gsm, int scoreL, int scoreR) {
        super(gsm);
        ball = new Ball();
        wall_1 = new Wall(650); wall_2 = new Wall(10);
        this.scoreR = scoreR;this.scoreL = scoreL;
        font = new BitmapFont(); shape = new ShapeRenderer();font.setColor(Color.WHITE); }

    @Override
    public void handleInput() {
        if(Gdx.input.isKeyPressed(Input.Keys.UP)){
            wall_1.update(true, false); }
        if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            wall_1.update(false, true); }
        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            wall_2.update(true, false); }
        if(Gdx.input.isKeyPressed(Input.Keys.S)){
            wall_2.update(false, true); } }

    @Override
    public void update(float dt) {
        ball.update();
        bounceBallStick();
        handleInput();

        if(ball.getX() + (ball.getWidth()/2) > Gdx.graphics.getWidth()){
            gsm.set(new PLAYstate(gsm, scoreL+1, scoreR));
            System.out.println("score Left: " + (scoreL + 1));
            System.out.println("Score Right: " + scoreR); }
        if(ball.getX() < ball.getWidth()/2){
            gsm.set(new PLAYstate(gsm, scoreL, scoreR+1));
            System.out.println("score Left: " + scoreL);
            System.out.println("Score Right: " + (scoreR + 1)); }
        getWinner(); }

    @Override
    public void render(SpriteBatch sb) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        shape.begin(ShapeRenderer.ShapeType.Filled);
        for(int i = 0; i < Gdx.graphics.getHeight()/20f-1; i+=2){
            shape.rect(Gdx.graphics.getWidth()/2f - 10f/2, 20f/2 + i * 20f, 3f, 8f); }
        shape.end();

        sb.begin();
        sb.draw(wall_1.getStick().getTexture(), wall_1.getX(), wall_1.getY() - (wall_1.getHeight() / 2));
        sb.draw(wall_2.getStick().getTexture(), wall_2.getX(), wall_2.getY() - (wall_2.getHeight() / 2));
        sb.draw(ball.getTexture(), ball.getX(), ball.getY());
        font.draw(sb, scoreL + "/" + scoreR, Gdx.graphics.getWidth()/2 - 20, Gdx.graphics.getHeight() - 10);
        sb.end(); }

    public void getWinner(){
        if(scoreR == 21){
            gsm.set(new WINNERstate(gsm, false, true)); }
        if(scoreL == 21){
            gsm.set(new WINNERstate(gsm, true, false)); } }

    public void bounceBallStick(){
        if(ball.collide(wall_1.getBounds())){
            ball.turnSpeed(); }
        if(ball.collide(wall_2.getBounds())){
            ball.turnSpeed(); } }

    @Override
    public void dispose() {
        ball.getTexture().dispose();
        wall_1.getStick().getTexture().dispose();
        wall_2.getStick().getTexture().dispose();
        shape.dispose();
    }
}
