package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MENUstate extends State {
    private Texture playBtn;
    public MENUstate(GSm gsm) {
        super(gsm);
        playBtn = new Texture("startBtn.png"); }

    @Override
    public void handleInput() {
        if(Gdx.input.isTouched()){
            gsm.set(new PLAYstate(gsm, 0, 0));
            dispose(); } }

    @Override
    public void update(float dt) {
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(playBtn, (App.WIDTH/2) - (playBtn.getWidth() / 2), (App.HEIGHT/2) - (playBtn.getHeight() / 2));
        sb.end(); }

    @Override
    public void dispose() {
        playBtn.dispose();
    }
}
