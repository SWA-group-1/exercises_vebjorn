package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;

public class Ball {
    private Texture ball;
    private Sprite ballSprite;
    private Rectangle bounds;
    private float speedX; private float speed_y;
    private int x; private int y;

    public Ball(){
        ball = new Texture("ball.png");
        ballSprite = new Sprite(ball);
        x = (Gdx.graphics.getWidth() / 2);
        y = (Gdx.graphics.getHeight() / 2);
        bounds = new Rectangle(x, y, (int)ballSprite.getWidth() +10, (int)ballSprite.getHeight() + 10);
        bounds.setPosition(x, y);
        speedX = 4f;
        speed_y = 4f; }

    public void update(){
        if(y > Gdx.graphics.getHeight() - ball.getHeight()/2 || y < ball.getHeight()/2){
            speed_y = -speed_y; }
        x += speedX; y += speed_y;
        bounds.setPosition(x, y); }
    public void turnSpeed(){
        speedX = -speedX;
    }

    public boolean collide(Rectangle rect){
        return rect.overlaps(bounds);
    }
    public Rectangle getBounds(){
        return bounds;
    }
    public int getX(){
        return x;
    } public int getY(){
        return y;
    }
    public float getWidth(){
        return ball.getWidth();
    }
    public float getHeight(){
        return ball.getHeight();
    }
    public Texture getTexture(){
        return ball;
    }
}
