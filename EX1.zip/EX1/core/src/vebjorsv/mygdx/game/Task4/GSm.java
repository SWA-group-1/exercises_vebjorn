package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.Stack;

public class GSm {
    private Stack<State> states;
    public GSm(){
        states = new Stack<State>();
    }
    public void push(State state){
        states.push(state);
    }
    public void pop(){
        states.pop();
    }
    public void set(State state){
        states.pop(); states.push(state); }
    public void update(float dt){
        states.peek().update(dt);
    }
    public void render(SpriteBatch sb){
        states.peek().render(sb);
    }
}
