package vebjorsv.mygdx.game.Task4;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;

public class Wall {
    private Texture wall;
    private Sprite stick;
    private float speedY;
    private int x; private int y;
    private Rectangle bounds;

    public Wall(int x){
        this.wall = new Texture("wall.png");
        this.stick = new Sprite(wall);
        this.speedY = 4f;
        this.x = x;
        y = (Gdx.graphics.getHeight() / 4) - (int)(stick.getHeight() / 4);
        bounds = new Rectangle(x, y, stick.getWidth() + 10, stick.getHeight() + 10);
        bounds.setPosition(x, y); }

    public void update(boolean up, boolean down){
        bounds.setPosition(x, y);

        if(up){
            if(y > Gdx.graphics.getHeight() - stick.getHeight()/2){
                speedY = 0; }
            if(y < 0 + stick.getHeight()/2){
                speedY = 2f;
                y += speedY; }
            else{
                y += speedY; } }
        if(down){
            if(y < 0 + stick.getHeight()/2){
                speedY = 0; }
            if(y > Gdx.graphics.getHeight() - stick.getHeight()/2){
                speedY = 2f;
                y -= speedY;
            } else{
                y -= speedY; } }
        bounds.setPosition(x, y); }

    public boolean collide(Rectangle rect){
        return rect.overlaps(bounds);
    }
    public Rectangle getBounds(){
        return bounds;
    }
    public float getHeight(){
        return stick.getHeight();
    }
    public Sprite getStick(){
        return stick;
    }
    public int getY(){
        return y;
    }
    public int getX(){
        return x;
    }
}
