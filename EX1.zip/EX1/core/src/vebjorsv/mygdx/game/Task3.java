package vebjorsv.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

public class Task3 extends ApplicationAdapter {
    Texture bg;
    SpriteBatch batch;
    List<Helicopter> helicopters;
    float stateTime;

    @Override
    public void create() {
        batch = new SpriteBatch();
        bg = new Texture(Gdx.files.internal("bg1.png"));
        helicopters = new ArrayList<>();
        helicopters.add(new Helicopter(50, 100, 3f)); helicopters.add(new Helicopter(100, 200, 4f));helicopters.add(new Helicopter(150, 300, 5f));
        stateTime = 0f; }

    @Override
    public void render() {
        Gdx.gl.glClearColor(234, 234, 236, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stateTime = Gdx.graphics.getDeltaTime();

        //COLLISION_helicopters
        for(Helicopter h : helicopters){
            for(Helicopter e : helicopters){
                if(h.collide(e.getBounds()) && h != e){
                    h.setSpeedX(-h.getSpeedX());
                    h.setSpeedY(-h.getSpeedY()); } } }
        //UPDATE_helicopter
        for(Helicopter h : helicopters){
            h.update(stateTime); }
        //FLIP_helicopters
        for(Helicopter h : helicopters){
            if(h.getSpeedX() >= 0){
                h.getCurrentFrame().flip(true, false); } }

        batch.begin();
        batch.draw(bg, 0, 0);
        for(Helicopter h : helicopters){
            batch.draw(h.getCurrentFrame(), h.getX() - (h.getSprite().getWidth() / 2), h.getY() - (h.getSprite().getHeight() / 2)); }
        //FLIP_helicopter
        for(Helicopter h : helicopters){
            if(h.getSpeedX() >= 0){
                h.getCurrentFrame().flip(true, false); } }
        batch.end(); }

    @Override
    public void dispose() {
        batch.dispose(); }
}
