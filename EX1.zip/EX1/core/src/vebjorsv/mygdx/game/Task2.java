package vebjorsv.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Task2 extends ApplicationAdapter {
    SpriteBatch batch; Sprite sprite;
    Texture helicopter; Texture bg;
    float speedX = 10f; float speedY = 10f;
    int x; int y;
    BitmapFont font;

    @Override
    public void create () {
        batch = new SpriteBatch();
        helicopter = new Texture("heli.png");
        bg = new Texture(Gdx.files.internal("bg1.png"));
        font = new BitmapFont();
        sprite = new com.badlogic.gdx.graphics.g2d.Sprite(helicopter);
        x = Gdx.graphics.getWidth()/2; y = Gdx.graphics.getHeight()/2;
        sprite.flip(true, false); }

    @Override
    public void render () {
        Gdx.gl.glClearColor(234, 234, 236, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        //UP, check top edge
        if(Gdx.input.isKeyPressed(Input.Keys.UP)){
            if(y >= Gdx.graphics.getHeight() - sprite.getHeight()/2){
                speedY = 0; }
            if(y < 0 + sprite.getWidth()/2){
                speedY = 10f;
                y += speedY; }
            else{ y += speedY; } }

        //DOWN, check  bottom edge
        if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            if(y <= 0 + sprite.getHeight()/2){
                speedY = 0; }
            if(y > Gdx.graphics.getHeight() - sprite.getHeight()/2){
                speedY = 10f;
                y -= speedY; }
            else{ y -= speedY; } }

        //LEFT, check left edge
        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            if(sprite.isFlipX()){
                sprite.flip(true, false); }
            if(x <= 0 + sprite.getWidth()/2){
                speedX = 0; }
            if(x > Gdx.graphics.getWidth() - sprite.getWidth()/2){
                speedX = 10f;
                x -= speedX;
            } else{
                x -= speedX; } }

        //RIGHT, check right edge
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            if(!sprite.isFlipX()){
                sprite.flip(true, false); }
            if(x >= Gdx.graphics.getWidth() - sprite.getWidth()/2){
                speedX = 0; }
            if(x < 0 + sprite.getWidth()/2){
                speedX = 10f;
                x += speedX;
            } else{ x += speedX; } }

        batch.begin();
        batch.draw(bg, 0, 0);
        font.draw(batch, "Coordinates: " + "( " + x + ", " + y + " )", 10, Gdx.graphics.getHeight() -10);
        batch.draw(sprite, x - sprite.getWidth()/2, y - sprite.getHeight()/2);
        batch.end();
    }
    @Override
    public void dispose () {
        batch.dispose();
    }
}
